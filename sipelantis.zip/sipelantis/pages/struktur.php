<?php

$ds = DIRECTORY_SEPARATOR;
$base_dir = realpath(dirname(__FILE__) . $ds . '..') . $ds;
require_once("{$base_dir}pages{$ds}core{$ds}header.php");

?>







<!-- <?php

require_once("{$base_dir}pages{$ds}core{$ds}footer.php");

?> -->